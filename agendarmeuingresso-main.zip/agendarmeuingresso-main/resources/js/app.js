import './bootstrap';

import '/vendor/power-components/livewire-powergrid/dist/powergrid';
import '/vendor/power-components/livewire-powergrid/dist/tailwind.css';


import flatpickr from "flatpickr";


window.Chart = Chart;
window.Sortable = Sortable;


