<div class="py-6">
    <div class="mx-auto sm:px-6">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 text-gray-900">
                {{ $slot }}
            </div>
        </div>
    </div>
</div>
