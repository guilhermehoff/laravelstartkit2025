<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\SiteServiceProvider::class,
];
